//
// Created by yuvalshechter on 18/12/2019.
//

#ifndef EX1_EX1_H
#define EX1_EX1_H

#include "Expression.h"
#include "Interpreter.h"
#include "BinaryOperator.h"
#include "UnaryOperator.h"
#include "Variable.h"
#include "Value.h"
#include "Plus.h"
#include "Div.h"
#include "Mul.h"
#include "Minus.h"
#include "UPlus.h"
#include "UMinus.h"

class ex1 {

};


#endif //EX1_EX1_H
